export class Regex {
  public constructor(
    public contact: string,
    public name: string,
    public password: string,
  ) {
  }
}
